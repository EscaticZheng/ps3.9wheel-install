#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Version info"""

short_version = '0.2'
version = '0.2.2'
