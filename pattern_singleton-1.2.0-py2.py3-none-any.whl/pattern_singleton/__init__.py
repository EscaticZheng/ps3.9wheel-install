from .pattern_singleton import Singleton

"""Top-level package for Pattern Singleton."""

__author__ = """Marcin Mysliwiec"""
__email__ = 'marcin.mysliw@gmail.com'
__version__ = '1.2.0'
